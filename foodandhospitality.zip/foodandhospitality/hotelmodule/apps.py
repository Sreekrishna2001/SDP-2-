from django.apps import AppConfig


class HotelmoduleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hotelmodule'
