from django.core.mail import send_mail


def confirmbooking_table():
    pass


def confirm_food_order():
    pass


def registration_success():
    pass
