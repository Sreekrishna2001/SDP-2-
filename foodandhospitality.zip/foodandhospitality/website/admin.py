from django.contrib import admin
from .models import uprofile,tablebooking,Orderfood
# Register your models here.

admin.site.register(uprofile)
admin.site.register(tablebooking)
admin.site.register(Orderfood)

